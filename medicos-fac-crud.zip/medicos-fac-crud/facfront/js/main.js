const apiUrl = 'http://localhost:3000/facturas';

const facturaForm = document.getElementById('facturaForm');
const idFacturaInput = document.getElementById('idFactura');
const nombresInput = document.getElementById('nombres');
const productoInput = document.getElementById('producto');
const cantidadInput = document.getElementById('cantidad'); 
const valorUnitarioInput = document.getElementById('valorUnitario');
const tablaFacturasBody = document.getElementById('tablaFacturasBody');

//Cargar Facturas al iniciar la página
window.onload = () => {
    cargarFacturas();
};

function cargarFacturas() {
    fetch(apiUrl)
    .then(res => res.json())
    .then(data => {
        tablaFacturasBody.innerHTML = '';//limpiar tabla
        data.forEach(factura => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
            <td>${factura.idFactura}</td>
            <td>${factura.nombres}</td>
            <td>${factura.producto}</td>
            <td>${factura.cantidad}</td>
            <td>${factura.valorUnitario}</td>
            <td>${factura.valorTotal}</td>
            <td>
                <button class="edit-btn" onclick="editarFactura('${factura.idFactura}')">Editar</button>
                <button class="delete-btn" onclick="eliminarFactura('${factura.idFactura}')">Eliminar</button>
            </td>
            `;
            tablaFacturasBody.appendChild(tr);
        });
    })
    .catch(err => alert('Error cargando Facturas: ' + err ));
}

//Guardar o actualizar Factura
facturaForm.addEventListener('submit', e => {
    e.preventDefault();

    const idFactura = idFacturaInput.value.trim();
    const nombres = nombresInput.value.trim();
    const producto = productoInput.value.trim();
    const cantidad = Number(cantidadInput.value.trim());
    const valorUnitario = Number(valorUnitarioInput.value.trim());
    const valorTotal = cantidad * valorUnitario;

    if ( !idFactura || !nombres || !producto || !cantidad || !valorUnitario ) {
        alert('Por favor complete todos los campos');
        return;
    }

    const facturaData = { idFactura, nombres, producto, cantidad, valorUnitario, valorTotal };

    //si existe el ID, hacemos PUT(editar); si no, POST(crear)
    const metodo = existefactura(idFactura) ? 'PUT' : 'POST'; // corregido
    const url = metodo === 'POST' ? apiUrl : `${apiUrl}/${idFactura}`;

    fetch(url, {
        method: metodo,
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(facturaData),
    })
    .then(res => {
        if (!res.ok) return res.json().then(e => Promise.reject(e.error));
        return res.json();
    })
    .then(() => {
        alert(metodo === 'POST' ? 'Factura agregada' : 'Factura actualizada'); 
        limpiarFormulario();
        cargarFacturas();
    })
    .catch(err => alert('Error ' + err));
})

//verifica si ya existe una Factura con ese ID
function existefactura(idFactura){
    return Array.from(tablaFacturasBody.children).some( // corregido
        row => row.children[0].textContent === idFactura // corregido
    );
}

//Llenar el formulario para editar
function editarFactura (idFactura) {
    fetch(apiUrl)
    .then(res => res.json())
    .then(data => {
        const factura = data.find(m => m.idFactura == idFactura);
        if (!factura) {
            alert('Factura no encontrada');
            return;
        }
        idFacturaInput.value = factura.idFactura;
        nombresInput.value = factura.nombres;
        productoInput.value = factura.producto;
        cantidadInput.value = factura.cantidad;
        valorUnitarioInput.value = factura.valorUnitario;
    });
}

//Eliminar Factura
function eliminarFactura(idFactura) {
    if (!confirm('¿Seguro que quieres eliminar esta factura?')) return;

    fetch(`${apiUrl}/${idFactura}`, { method: 'DELETE'})
    .then(res => {
        if (!res.ok) throw new Error('Error al eliminar factura');
        return res.json()
    })
    .then(() => {
        alert('Factura eliminada');
        cargarFacturas();
    })
    .catch(err => alert(err))
}

//Limpiar formulario
function limpiarFormulario(){
    idFacturaInput.value = '';
    nombresInput.value = '';
    productoInput.value = '';
    cantidadInput.value = '';
    valorUnitarioInput.value = '';
}
