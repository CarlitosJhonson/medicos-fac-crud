const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: true}));

let facturas = [];

app.get('/facturas', (req,res) => {
    res.json(facturas);
});

app.post('/facturas', (req, res) => {
    const { idFactura, nombres, producto, cantidad, valorUnitario, valorTotal } = req.body;

    const existe = facturas.find( m => m.idFactura === idFactura);
    if (existe) {
        return res.status(400).json({error: 'La factura ya existe'})
    }

    const nuevaFactura = { idFactura,  nombres, producto, cantidad, valorUnitario, valorTotal};
    facturas.push(nuevaFactura);
    res.status(201).json(nuevaFactura);
});

app.put('/facturas/:id', (req,res) => {
    const id = req.params.id;
    const {  nombres, producto, cantidad, valorUnitario, valorTotal } = req.body;

    // Comparación tolerante a tipo (número vs string)
    const facturaIndex = facturas.findIndex(m => m.idFactura == id);
    if (facturaIndex === -1) {
        return res.status(404).json({error: 'Factura no encontrada'});
    }

    if (nombres) facturas[facturaIndex].nombres = nombres;
    if (producto) facturas[facturaIndex].producto = producto;
    if (cantidad) facturas[facturaIndex].cantidad = cantidad;
    if (valorUnitario) facturas[facturaIndex].valorUnitario = valorUnitario;
    if (valorTotal) facturas[facturaIndex].valorTotal = valorTotal;

    res.json(facturas[facturaIndex]);
});


app.delete('/facturas/:idFactura', (req, res) => {
    const id = req.params.idFactura;

    const facturaIndex = facturas.findIndex(m => m.idFactura === id);
    if (facturaIndex === -1) {
        return res.status(404).json({error: 'Factura no encontrada'});
    };

    const eliminada = facturas.splice(facturaIndex, 1);

    res.json({ mensaje: 'Factura eliminada', factura: eliminada[0] });
});

app.listen(3000, () => {
    console.log('Servidor escuchando en http://localhost:3000');
});